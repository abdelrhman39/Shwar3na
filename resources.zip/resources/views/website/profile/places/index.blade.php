@extends('website.profile.main')

@section('content_profile')

    <div class="dashboard-list-box fl-wrap">
        <div class="dashboard-header fl-wrap">
            <h3>محلاتى</h3>
        </div>
        <!-- dashboard-list end-->
            @foreach($myPlaces as $place)
            <div class="dashboard-list">
                <div class="dashboard-message">
                    {{--  <span class="new-dashboard-item">New</span>  --}}
                    <div class="dashboard-listing-table-image">
                        <a href="{{ url('places/'.$place->id) }}">
                            <img src="uploads/places/{{$place->logo}}"alt=""></a>
                    </div>
                    <div class="dashboard-listing-table-text">
                        <h4><a href="{{ url('places/'.$place->id) }}">{{$place->name_ar}} - {{$place->name_en}}</a></h4>
                        <span class="dashboard-listing-table-address"><i class="fa fa-map-marker" style="float: right;margin-left:10px; margin-right: -10px"></i>
                                    <a href="#">{{$place->address}}</a></span>
                        <div class="listing-rating card-popup-rainingvis fl-wrap"
                            data-starrating2="{{$place->rate}}">
                            <span>(2 reviews)</span>
                        </div>
                        <ul class="dashboard-listing-table-opt  fl-wrap">
                            <li><a href="{{ url('editePlace/'.$place->id) }}">Edit <i class="fa fa-pencil-square-o"></i></a>
                            </li>
                            <li>
                                <form action="{{ url('deletePlace/'.$place->id) }}" method="POST">
                                    @csrf
                                    @method('delete')
                                    <button onclick="confirm('يرجي العلم انه سيتم حذف الكوبونات والخصومات ايضا مع حذف المحل.. هل انت متأكد من الحذف؟');" type="submit" class="del-btn">Delete <i class="fa fa-trash-o"></i></button>
                                </form>

                            </li>
                            <li><a href="{{ url('user-coupouns/'.$place->id) }}">عروض هذا المحل <i class="fas fa-bomb"></i></a>
                            </li>

                            <li><a class="del-btn" href="{{ url('place-products/'.$place->id) }}">منتجات هذا المحل <i class="fas fa-shopping-basket"></i></a>
                            </li>

                            <li><a class="del-btn" style="margin-top: 10px;" href="{{ url('place-job/'.$place->id) }}">وظائف هذا المحل <i class="fas fa-shopping-basket"></i></a>
                            </li>
                            {{--  <li><a href="#" class="del-btn">Delete <i
                                        class="fa fa-trash-o"></i></a></li>  --}}
                        </ul>
                    </div>
                </div>
            </div>


            @endforeach

        <!-- dashboard-list end-->

    </div>
    <!-- pagination-->
    {{ $myPlaces->links('vendor.pagination.new_pagi') }}


@endsection

