<?php

namespace App\Http\Controllers\Site\profile;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\Place;

class MyPlaceController extends Controller
{  

    
}