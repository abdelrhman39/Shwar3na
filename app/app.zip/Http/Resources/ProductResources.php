<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Controllers\Manage\BaseController;

class ProductResources extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id, 
            "name" => $this->name,
            "description" => $this->description,
            "main_image" => BaseController::getImageUrl("products" , $this->main_image),
            "price" => $this->old_price,
            "new_price" => $this->new_price,
            "rate" => $this->rate,
            "created_at" => $this->created_at,
        ];
    }
}
