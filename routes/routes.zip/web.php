<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Site\mainController;
use App\Http\Controllers\Site\UserController;
use App\Http\Controllers\Site\profile\MyPlaceController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
// */
// Route::view('/welcome', 'welcome');
// Route::any('{all}', [mainController::class, 'homePage'])->where('all', '^(?!api).*$');

Auth::routes();
Route::get('/get_subcategory{id}', [mainController::class, 'get_subcategory']);
Route::get('/logout', [mainController::class, 'site_logout'])->name('logout');

Route::get('/contactUs', [mainController::class, 'contactUs'])->name('site.contactUs');

Route::group([ 'middleware' => 'guest'], function() {
    
    Route::get('/', [mainController::class, 'homePage'])->name('get.site');
    Route::get('/index', [mainController::class, 'homePage'])->name('get.site');

    Route::post('/Site_login', [UserController::class, 'Site_login'])->name('site.login');

    Route::post('/Site_register', [UserController::class, 'Site_register']);


});

Route::group([ 'middleware' => 'auth:web'], function() {

    Route::get('/home', [UserController::class, 'homePage'])->name('get.site');

    Route::get('/profileDashboard', [UserController::class, 'profile_dash'])->name('site.profile.dash');

});