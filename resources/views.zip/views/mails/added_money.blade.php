<html>
    <head>
        <title></title>

    </head>
    <body>


        <h2>تم شحن حسابك بقيمه {{ $money }} L.E</h2>
        <h2> اجمالي رصيد حسابك الان  {{  $total_user_balance }} L.E  </h2>
        <h2>قم بزياره موقع شوارعنا من خلال الرابط <a href="{{ url('') }}">Shwar3na.com</a></h2>
        <h2> او من خلال الQR</h2>
        <img src="http://shwar3na.com/Qr_shwr3na.png" width="250px" height="250px">
    </body>
</html>
